+===================+
|                   |
|     PIXEL MAN     |
|                   |
+===================+
A Zombie Shooter
     for Windows OS
     by Glenn Storm
     January 2020

(C++,SFML,CodeBlocks)

Keep all files and
 folders in place
 (like openal32.dll)

Make a shortcut to
 PixelMan.exe and
 place anywhere

NOTE: All graphics 
 and sounds are 
 stolen (with thanks)
